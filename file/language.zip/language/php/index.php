<?php
// ==============================================  >>> CLASS <<<  ==============================================
// ------------------ > Public < ------------------
class Car
{
/*
خاصية: نصية، عامة يمكن الوصول لها من داخل/خارج الكلاس
*/
    public string $brand;
}



$car1 = new Car();
echo $car1->brand = "Toyota";
// ------------------ > Public < ------------------









// ------------------ > Private < ------------------
class Car
{
/*
خاصية: نصية، خاصة يمكن الوصول لها من داخل دالة بالكلاس لوضع شروط عليها عكس العامة
*/
    private string $brand;

    public function setBrand(string $Brand)
    {
        if ($Brand == "")
        {
            echo "Brand is required";
            return;
        }
        
        return $this->brand = $Brand;
    }
}



$car1 = new Car();
echo $car1->setBrand("Toyota");
// ------------------ > Private < ------------------










// ------------------ > نوع Return < ------------------
class Car
{
    private int $price;
/*
دالة تستدعى تلقائيا عند إنشاء Object وتستقبل معاملا رقميا، وتخزنه في خاصية الObject عبر this->price.
*/
    public function __construct(int $price)
    {
        $this->price = $price;
    }
/*
دالة: عامة، تستقبل معاملا رقميا لتغيير قيمة الخاصية المخزنة في الأوبجكت.
تنفذ عملية فقط ولا تُرجع شيئا.
*/
    public function setPrice(int $price): void
    {
        $this->price = $price;
    }
/*
دالة: عامة، لعرض قيمة الخاصية المخزنة في الأوبجكت.
ترجع عددا فقط.
*/
    public function getPrice(): int
    {
        return $this->price;
    }
}


/*
خزن في متغير أوبجكت جديد من كلاس Car، مع تمرير القيمة إلى الدالة البانية.
*/
$car1 = new Car(2000);
echo $car1->getPrice();
echo PHP_EOL;
/*
استدعاء الدالة العامة من الأوبجكت car1.
*/
$car1->setPrice(3000);
echo $car1->getPrice();
// ------------------ > نوع Return < ------------------









// ------------------ > الوراثة < ------------------
class Vehicle
{
/*
خاصية: تزيد عن private بأنه يمكن الوصول إليها من الأبناء
*/
    protected string $brand;

    public function __construct(string $brand)
    {
        $this->brand = $brand;
    }

    public function getBrand(): string
    {
        return $this->brand;
    }
}


/*
كلاس يرث كل مافي الأب
*/
class Car extends Vehicle
{
    private int $doors;

    public function __construct(string $brand, int $doors)
    {
/*
استدعِ الـ Constructor الأب لتهيئة الخصائص الموروثة قبل تهيئة خصائص الكلاس الحالي.
*/
        parent::__construct($brand);
        $this->doors = $doors;
    }
    public function getDoors(): int
    {
        return $this->doors;
    }
}



$car1 = new Car("Toyota", 4);
echo $car1->getBrand();
echo PHP_EOL;

echo $car1->getDoors();
// ------------------ > الوراثة < ------------------
